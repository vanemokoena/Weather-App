import React from 'react';
import './App.css';
import WeatherApp from './components/WeatherApp'; // Importing WeatherApp component



function App() {
  return (
    
    <div className="App">
      <WeatherApp /> {/* Rendering the WeatherApp component */}
    </div>
  );
}

export default App;
