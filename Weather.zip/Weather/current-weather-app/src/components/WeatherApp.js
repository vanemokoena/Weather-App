
import React, { useState } from "react";


function WeatherApp() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);

  const apiKey = process.env.REACT_APP_WEATHER_API_KEY;

  const fetchWeather = async (lat, lon) => {
    let url;
    if (lat && lon) {
      // Fetching weather using coordinates
      url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${lat},${lon}`;
    } else if (city) {
      // Fetch weather using city name
      url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;
    } else {
      setError("Please enter a city or allow location access.");
      return;
    }
    
    try {
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setWeather(data);
        setError(null);
      } else {
        setError("City not found.");
        setWeather(null);
      }
    } catch (err) {
      setError("An error occurred while fetching data.");
    }
  };
 //getting the current location
 //i couldnt get current location, please help me if possible.
  const getCurrentLocationWeather = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          fetchWeather(latitude, longitude);
        },
        (error) => {
          
          // Logging the error reason
          // eslint-disable-next-line default-case
          switch(error.code) {
            case error.PERMISSION_DENIED:
              setError("User denied the request for Geolocation.");
              break;
            case error.POSITION_UNAVAILABLE:
              setError("Location information is unavailable.");
              break;
            case error.TIMEOUT:
              setError("The request to get user location timed out.");
              break;
            case error.UNKNOWN_ERROR:
              setError("An unknown error occurred.");
              break;
          }
        }
      );
    }else {
      setError("Geolocation is not supported by this browser.");
    }
  };
  
  return (
    <div className="weather-container">
      <h1>Current Weather App</h1>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button onClick={() => fetchWeather()}>Get Weather</button>
      <button onClick={getCurrentLocationWeather}>Allow Weather App to get your location</button>
      {error && <p className="error">{error}</p>}
      {weather && (
        <div className="weather-info">
          <h2>{weather.location.name}</h2>
          <p>Temperature: {weather.current.temp_c}°C</p>
          <p>Condition: {weather.current.condition.text}</p>
          
        </div>
      )}
    </div>
  );
}

export default WeatherApp;
